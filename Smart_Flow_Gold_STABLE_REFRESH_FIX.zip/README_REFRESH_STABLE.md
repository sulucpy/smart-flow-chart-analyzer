# Smart Flow Gold — Stable Refresh Fix

This version keeps the full Live XAUUSD + Smart Flow + Big Candle + S/R + Telegram + Backtest features.

## Refresh fix
- Removes the old full-page `st_autorefresh` loop.
- Uses a Streamlit fragment so only the live dashboard reruns.
- Backtest and Telegram controls remain stable.
- Live refresh defaults to 5 seconds and can be adjusted in the sidebar.
- Historical REST data remains cached.
- WebSocket feed remains a background resource.

## Secrets
```toml
SIFTINGIO_API_KEY = "YOUR_SIFTINGIO_KEY"
TELEGRAM_BOT_TOKEN = "YOUR_TELEGRAM_BOT_TOKEN"
TELEGRAM_CHAT_ID = "YOUR_TELEGRAM_CHAT_ID"
```
